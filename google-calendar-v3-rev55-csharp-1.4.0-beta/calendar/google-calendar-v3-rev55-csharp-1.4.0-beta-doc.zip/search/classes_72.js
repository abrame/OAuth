var searchData=
[
  ['remindersdata',['RemindersData',['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1Data_1_1Event_1_1RemindersData.html',1,'Google::Apis::Calendar::v3::Data::Event']]]
];
