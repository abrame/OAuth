var searchData=
[
  ['patch',['Patch',['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1CalendarListResource.html#ab14a6f4c063d84f8e1124a36b4f8019f',1,'Google::Apis::Calendar::v3::CalendarListResource.Patch()'],['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1CalendarsResource.html#a56a671f9736b4c130d2b40718b66e81d',1,'Google::Apis::Calendar::v3::CalendarsResource.Patch()'],['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1AclResource.html#a1f2dbaf7c726ed1080fc3b004973dbf4',1,'Google::Apis::Calendar::v3::AclResource.Patch()'],['../classGoogle_1_1Apis_1_1Calendar_1_1v3_1_1EventsResource.html#aa3248db8acfa4836c569f57a6e09bf2b',1,'Google::Apis::Calendar::v3::EventsResource.Patch()']]]
];
